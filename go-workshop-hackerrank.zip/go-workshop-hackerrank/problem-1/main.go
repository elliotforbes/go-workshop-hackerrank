package main

import (
    "fmt"
)

// Complete the sockMerchant function below.
func SockMerchant(n int32, ar []int32) int32 {
	/*
	 * Implement this function
	 */ 

    return 0
}

func main() {
	fmt.Println("Go SockMerchant Challenge")
}
